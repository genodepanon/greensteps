<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>DB Manager</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#0b2a3b; color:#e2e8f0; margin:0; padding:20px; }
        h1 { color:#7dd3fc; margin:0 0 16px; font-size:1.4rem; }
        a { color:#7dd3fc; text-decoration:none; }
        a:hover { text-decoration:underline; }
        .btn { background:#2d7a4f; color:white; border:none; padding:8px 16px; border-radius:8px; cursor:pointer; font-weight:600; text-decoration:none; display:inline-block; }
        .btn:hover { background:#23673f; }
        .btn-danger { background:#dc2626; }
        .btn-danger:hover { background:#991b1b; }
        .btn-secondary { background:#334155; }
        .btn-secondary:hover { background:#475569; }
        .card { background:#123a4f; border-radius:12px; padding:20px; margin-bottom:16px; }
        .login-box { max-width:400px; margin:80px auto; }
        input[type=text], input[type=password], input[type=date], textarea, select {
            padding:10px; border-radius:8px; border:1px solid #334155; background:#0b2a3b; color:#e2e8f0; font-family:inherit; font-size:0.95rem;
        }
        input[type=text], input[type=password], textarea, select { width:100%; }
        label { display:block; margin:12px 0 4px; font-size:0.85rem; color:#94a3b8; font-weight:600; }
        table { width:100%; border-collapse:collapse; font-size:0.82rem; }
        th, td { padding:8px 10px; text-align:left; border-bottom:1px solid #1e3a4f; vertical-align:top; max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        th { color:#7dd3fc; font-weight:600; background:#0b2a3b; position:sticky; top:0; }
        tr:hover { background:#1a4358; }
        .tabs { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:16px; }
        .tabs a { padding:6px 14px; background:#123a4f; border-radius:20px; font-size:0.85rem; }
        .tabs a.active { background:#2d7a4f; color:white; }
        .error { background:#7f1d1d; color:#fecaca; padding:10px 14px; border-radius:8px; margin-bottom:12px; font-size:0.85rem; }
        .flash { background:#14532d; color:#bbf7d0; padding:10px 14px; border-radius:8px; margin-bottom:12px; font-size:0.85rem; }
        .actions { display:flex; gap:6px; white-space:nowrap; }
        .small { font-size:0.75rem; color:#64748b; }
        .form-row { margin-bottom:8px; }
        .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
        .topbar-right { display:flex; gap:12px; align-items:center; }

        /* Log-specific */
        .log-filters { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; margin-bottom:16px; }
        .log-filters .f { display:flex; flex-direction:column; }
        .log-filters .f label { margin:0 0 4px 0; }
        .log-filters input, .log-filters select { min-width:140px; }
        .action-pill { padding:3px 10px; border-radius:40px; font-size:0.7rem; font-weight:700; letter-spacing:0.3px; text-transform:uppercase; white-space:nowrap; }
        .action-LOGIN          { background:#dbeafe; color:#1e4a7a; }
        .action-LOGOUT         { background:#f1f5f9; color:#475569; }
        .action-REGISTER       { background:#dcfce7; color:#166534; }
        .action-SUBMIT_REPORT  { background:#fef3c7; color:#92400e; }
        .action-ASSIGN_TEAM    { background:#ede9fe; color:#6d28d9; }
        .action-START_TASK     { background:#e0f2fe; color:#0369a1; }
        .action-COMPLETE_TASK  { background:#dcfce7; color:#166534; }
        .action-REJECT_TASK    { background:#fee2e2; color:#991b1b; }
        .action-REJECT_REPORT  { background:#fee2e2; color:#991b1b; }
        .action-RATE_TEAM      { background:#fef3c7; color:#92400e; }
        .action-UPDATE_PROFILE { background:#dbeafe; color:#1e4a7a; }
        .action-other          { background:#e2e8f0; color:#334155; }
        .ip-col { font-family: ui-monospace, monospace; font-size:0.75rem; color:#94a3b8; }
        .time-col { font-family: ui-monospace, monospace; font-size:0.75rem; color:#94a3b8; }
    </style>
</head>
<body>

<?php if($stage === 'login'): ?>
    <div class="card login-box">
        <h1>DB Manager · Login</h1>
        <?php if(session('error')): ?>
            <div class="error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <form method="POST" action="/axel/login">
            <?php echo csrf_field(); ?>
            <label>Password</label>
            <input type="password" name="password" autofocus required>
            <div style="margin-top:16px;"><button class="btn" type="submit">Enter</button></div>
        </form>
    </div>
<?php endif; ?>

<?php if($stage === 'table'): ?>
    <div class="topbar">
        <h1>DB Manager · <code style="color:#94a3b8;"><?php echo e($table); ?></code> <span class="small">(<?php echo e($count); ?> rows, showing up to 200)</span></h1>
        <div class="topbar-right">
            <a class="btn btn-secondary" href="/axel/create?table=<?php echo e(urlencode($table)); ?>">+ New row</a>
            <a class="btn btn-secondary" href="/axel/logs">📜 Activity Log</a>
            <a class="btn btn-secondary" href="/axel/logout">Logout</a>
        </div>
    </div>

    <div class="tabs">
        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/axel?table=<?php echo e(urlencode($t)); ?>" class="<?php echo e($t === $table ? 'active' : ''); ?>"><?php echo e($t); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($flash): ?><div class="flash"><?php echo e($flash); ?></div><?php endif; ?>
    <?php if($error): ?><div class="error"><?php echo e($error); ?></div><?php endif; ?>

    <div class="card" style="overflow-x:auto;">
        <?php if(count($rows) === 0): ?>
            <p class="small">No rows.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($col); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td title="<?php echo e(is_scalar($row->$col ?? '') ? $row->$col : json_encode($row->$col)); ?>"><?php echo e(\Illuminate\Support\Str::limit((string)($row->$col ?? ''), 60)); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <div class="actions">
                                    <a class="btn" style="padding:4px 10px; font-size:0.75rem;" href="/axel/row?table=<?php echo e(urlencode($table)); ?>&id=<?php echo e($row->id); ?>">Edit</a>
                                    <form method="POST" action="/axel/delete" onsubmit="return confirm('Delete row #<?php echo e($row->id); ?> from <?php echo e($table); ?>?');" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="__table" value="<?php echo e($table); ?>">
                                        <input type="hidden" name="__id" value="<?php echo e($row->id); ?>">
                                        <button class="btn btn-danger" style="padding:4px 10px; font-size:0.75rem;" type="submit">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if($stage === 'row'): ?>
    <div class="topbar">
        <h1>Edit row #<?php echo e($row['id']); ?> in <code><?php echo e($table); ?></code></h1>
        <div class="topbar-right">
            <a class="btn btn-secondary" href="/axel?table=<?php echo e(urlencode($table)); ?>">← Back</a>
        </div>
    </div>

    <?php if($flash): ?><div class="flash"><?php echo e($flash); ?></div><?php endif; ?>
    <?php if($error): ?><div class="error"><?php echo e($error); ?></div><?php endif; ?>

    <div class="card">
        <form method="POST" action="/axel/update">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="__table" value="<?php echo e($table); ?>">
            <input type="hidden" name="__id" value="<?php echo e($row['id']); ?>">
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($col === 'id'): ?> <?php continue; ?> <?php endif; ?>
                <div class="form-row">
                    <label><?php echo e($col); ?></label>
                    <?php
                        $val = $row[$col] ?? '';
                        $isLong = is_string($val) && strlen($val) > 80;
                    ?>
                    <?php if($isLong): ?>
                        <textarea name="<?php echo e($col); ?>" rows="4"><?php echo e($val); ?></textarea>
                    <?php else: ?>
                        <input type="text" name="<?php echo e($col); ?>" value="<?php echo e($val); ?>" placeholder="(leave blank to keep empty) — type __NULL__ for NULL">
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-top:16px; display:flex; gap:10px;">
                <button class="btn" type="submit">Save changes</button>
                <a class="btn btn-secondary" href="/axel?table=<?php echo e(urlencode($table)); ?>">Cancel</a>
            </div>
        </form>

        <hr style="margin:24px 0; border:none; border-top:1px solid #1e3a4f;">
        <form method="POST" action="/axel/delete" onsubmit="return confirm('Delete row #<?php echo e($row['id']); ?>?');">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="__table" value="<?php echo e($table); ?>">
            <input type="hidden" name="__id" value="<?php echo e($row['id']); ?>">
            <button class="btn btn-danger" type="submit">Delete this row</button>
        </form>
    </div>
<?php endif; ?>

<?php if($stage === 'create'): ?>
    <div class="topbar">
        <h1>New row in <code><?php echo e($table); ?></code></h1>
        <div class="topbar-right">
            <a class="btn btn-secondary" href="/axel?table=<?php echo e(urlencode($table)); ?>">← Back</a>
        </div>
    </div>

    <?php if($flash): ?><div class="flash"><?php echo e($flash); ?></div><?php endif; ?>
    <?php if($error): ?><div class="error"><?php echo e($error); ?></div><?php endif; ?>

    <div class="card">
        <form method="POST" action="/axel/store">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="__table" value="<?php echo e($table); ?>">
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($col === 'id'): ?> <?php continue; ?> <?php endif; ?>
                <div class="form-row">
                    <label><?php echo e($col); ?></label>
                    <input type="text" name="<?php echo e($col); ?>" value="" placeholder="(empty) — type __NULL__ for NULL">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-top:16px; display:flex; gap:10px;">
                <button class="btn" type="submit">Insert row</button>
                <a class="btn btn-secondary" href="/axel?table=<?php echo e(urlencode($table)); ?>">Cancel</a>
            </div>
        </form>
    </div>
<?php endif; ?>

<?php if($stage === 'logs'): ?>
    <div class="topbar">
        <h1>📜 Activity Log <span class="small">(<?php echo e(count($logs)); ?> entries, newest first)</span></h1>
        <div class="topbar-right">
            <a class="btn btn-secondary" href="/axel">← Back to tables</a>
            <form method="POST" action="/axel/logs/clear" onsubmit="return confirm('Delete ALL log entries? This cannot be undone.');" style="display:inline;">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger" type="submit">Clear log</button>
            </form>
        </div>
    </div>

    <?php if($flash): ?><div class="flash"><?php echo e($flash); ?></div><?php endif; ?>

    <div class="card">
        <form method="GET" action="/axel/logs">
            <div class="log-filters">
                <div class="f">
                    <label>Search (name / details / IP)</label>
                    <input type="text" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" placeholder="Sara, team alpha, 127.0...">
                </div>
                <div class="f">
                    <label>Action</label>
                    <select name="action">
                        <option value="">All</option>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a); ?>" <?php echo e(($filters['action'] ?? '') === $a ? 'selected' : ''); ?>><?php echo e($a); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="f">
                    <label>From date</label>
                    <input type="date" name="from" value="<?php echo e($filters['from'] ?? ''); ?>">
                </div>
                <div class="f">
                    <label>To date</label>
                    <input type="date" name="to" value="<?php echo e($filters['to'] ?? ''); ?>">
                </div>
                <div class="f">
                    <button class="btn" type="submit">Filter</button>
                </div>
                <div class="f">
                    <a class="btn btn-secondary" href="/axel/logs">Reset</a>
                </div>
            </div>
        </form>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Time</th>
                    <th>User</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $pillClass = in_array($log->action, [
                            'LOGIN','LOGOUT','REGISTER','SUBMIT_REPORT','ASSIGN_TEAM',
                            'START_TASK','COMPLETE_TASK','REJECT_TASK','REJECT_REPORT',
                            'RATE_TEAM','UPDATE_PROFILE'
                        ]) ? 'action-' . $log->action : 'action-other';
                    ?>
                    <tr>
                        <td class="small">#<?php echo e($log->id); ?></td>
                        <td class="time-col"><?php echo e($log->created_at); ?></td>
                        <td><?php echo e($log->user_name ?? '—'); ?></td>
                        <td class="small"><?php echo e($log->user_role ?? '—'); ?></td>
                        <td><span class="action-pill <?php echo e($pillClass); ?>"><?php echo e($log->action); ?></span></td>
                        <td title="<?php echo e($log->details); ?>"><?php echo e(\Illuminate\Support\Str::limit((string)($log->details ?? ''), 80)); ?></td>
                        <td class="ip-col"><?php echo e($log->ip_address ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($logs) === 0): ?>
                    <tr><td colspan="7" class="small" style="text-align:center; padding:20px;">No log entries match your filters.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\greensteps\resources\views/secret.blade.php ENDPATH**/ ?>